BOT_TOKEN = ""

phone =""

token "

publick_key = ""

logchat = -

channel = -