from . import fag,start,profile,buttons,answers,functions,keyboard,podpiski,attack,admin,plushki, qiwi



'''
fag = меню фаг 
start = приветсвенное смс + занесение в бд
proflie = меню профиля 
qiwi = пополнения баланса
buttons = ответы на инлайн кнопки
answers = хранение больших текстов
functions = операции с бд
keyboard = кнопочки
attack = меню спама
admin = всё для админов
'''